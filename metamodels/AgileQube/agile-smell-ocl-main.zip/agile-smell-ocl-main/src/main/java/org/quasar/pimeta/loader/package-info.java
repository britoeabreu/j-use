/**
 * 
 */
/**
 * @author fba
 *
 */
package org.quasar.pimeta.loader;
/**
 * 
 */
/**
 * @author fba
 *
 */
package org.quasar.toolkit;
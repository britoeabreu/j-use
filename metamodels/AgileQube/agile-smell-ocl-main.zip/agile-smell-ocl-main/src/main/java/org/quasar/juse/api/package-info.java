/**
 * 
 */
/**
 * @author fba
 *
 */
package org.quasar.juse.api;
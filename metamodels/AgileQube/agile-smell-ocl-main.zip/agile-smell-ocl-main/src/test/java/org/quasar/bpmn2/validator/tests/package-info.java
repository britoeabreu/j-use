/**
 * 
 */
/**
 * @author fba
 *
 */
package org.quasar.bpmn2.validator.tests;